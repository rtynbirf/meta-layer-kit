# ПУТЬ БЕЗ ТЕРМИНАЛА И БЕЗ КЛЮЧА

Суть: браузер, в котором ты уже залогинен в GitHub, — это и есть
авторизация. Ключ не нужен вообще. Ничего не вставляется, ничего не
печатается, никаких скрытых вводов. Подходит для экранного чтения и
голосового управления: у GitHub подписи у всех кнопок и полей.

## Путь А — браузер (ноль терминала, ноль ключей)

1. Открой github.com/new
2. Repository name: `meta`
3. Public (карта из публичных данных — публична)
4. Кнопка Create repository
5. На открывшейся странице — ссылка «uploading an existing file»
6. В файл-пикере выбери из папки `meta-layer/orbit` пять файлов:
   `README.md`, `MAP.md`, `map.json`, `api-capture.json`, `meta_snapshot.py`
7. Кнопка Commit changes
8. Add file → Create new file → набери путь
   `.github/workflows/meta-drift.yml` → вставь содержимое из раздела
   «Файл 1» ниже → Commit changes
9. Add file → Create new file → путь
   `.github/workflows/meta-map.yml` → содержимое из «Файл 2» → Commit changes
10. Готово: карта вселенной в аккаунте. Вкладка Actions: CI-страж
    `meta-drift` встал на пост, бот `meta-map` пересобирает карту ночью.

Примечание: если первый прогон meta-drift красный — это не поломка: карта
из архива могла отстать от живого API. Бот meta-map пересоберёт её из
живого API, и всё позеленеет через минуту-две.

## Путь Б — один человек или ассистент рядом (60 секунд)

В папке meta-layer: `bash bootstrap.sh` → вставить ключ в скрытый ввод →
репо создано и вселено. Ключ живёт в памяти одного процесса: не в файлах,
не в логах, не в .git/config.

## Путь В — честная граница

Если недоступны и браузер, и помощник — пуш невозможен ни для кого в мире,
не только для меня: в GitHub с чужого пульта без ключа не входит никто.
Работа при этом не пропала: карта вселенной собрана и лежит в архиве,
готовая к вселению в день, когда появится любой входной канал.

## Файл 1: .github/workflows/meta-drift.yml

```yaml
name: meta-drift
on:
  push:
  pull_request:
jobs:
  drift:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Карта обязана совпадать с живым публичным API (иначе красный)
        run: python3 meta_snapshot.py drift --login rtynbirf --root .
```

## Файл 2: .github/workflows/meta-map.yml

```yaml
name: meta-map
on:
  push:
    branches: [main]
  schedule:
    - cron: "0 4 * * *"
permissions:
  contents: write
jobs:
  map:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Пересобрать карту из живого публичного API
        run: python3 meta_snapshot.py snapshot --login rtynbirf --root .
      - name: Вселить обновлённую карту, если она изменилась
        run: |
          git config user.name "meta-bot"
          git config user.email "meta-bot@users.noreply.github.com"
          git add MAP.md map.json
          if git diff --cached --quiet; then
            echo "карта актуальна"
          else
            git commit -qm "meta: карта пересобрана из живого API [skip ci]"
            git push
          fi
```

## Что требует тела — честно, по шагам

| Шаг | Что нужно |
|---|---|
| Скачать zip | один клик |
| Распаковать | один клик (двойной) |
| Путь А | браузер: клики или голосовое управление; вставка только содержимого двух коротких файлов из этого документа |
| Путь Б | терминал + одна вставка ключа |
| Я сам | не могу: ключ через себя не идёт — конструкция, а не каприз |

Единственное действие, которого не существует обходом, — сделать что-то от
имени владельца аккаунта. Всё остальное kit делает сам.
