#!/usr/bin/env bash
# bootstrap.sh — ОДНА команда владельца.
#   bash bootstrap.sh            → спросит ключ скрытым вводом, сам создаст репо meta и вселит карту
#   bash bootstrap.sh --dry-run  → соберёт мета-репо локально; ключ не трогает, пуша нет
# Ключ живёт только в памяти процесса: не в файлах, не в argv, не в логах, не в .git/config.
set -euo pipefail
cd "$(dirname "$0")"

DRY=0
[ "${1:-}" = "--dry-run" ] && DRY=1

BUILD=$(mktemp -d /tmp/meta-repo.XXXXXX)
cp -a orbit/. "$BUILD"/
cd "$BUILD"
git init -q -b main
git add -A
git -c user.name="meta-bootstrap" -c user.email="meta-bootstrap@localhost" \
  commit -qm "meta: карта вселенной из публичного API. Подделка = красный CI."
echo "✓ мета-репо собрано локально: файлов $(git ls-files | wc -l), коммитов $(git rev-list --count HEAD)"
git ls-files

if [ "$DRY" = 1 ]; then
  echo "СУХОЙ ПРОГОН: ключ не спрашивал, в аккаунт не входил, пуша не было."
  echo "Живой прогон: bash bootstrap.sh   (ключ — скрытый ввод)"
  exit 0
fi

read -rsp "Вставь ключ (ввод скрыт): " GH_TOKEN
echo
if [ -z "${GH_TOKEN:-}" ]; then echo "✗ Ключ пуст — стоп."; exit 1; fi

USER_JSON=$(curl -s -H "Authorization: Bearer ${GH_TOKEN}" \
  -H "Accept: application/vnd.github+json" https://api.github.com/user)
LOGIN=$(printf '%s' "$USER_JSON" | python3 -c "import sys,json;print(json.load(sys.stdin).get('login',''))" || true)
if [ -z "${LOGIN:-}" ]; then
  echo "✗ Ключ не открыл дом (неверный или просроченный). Ответ API не печатаю."
  exit 1
fi
echo "Ключ открывает дом: ${LOGIN}. Создаю репо meta..."

HTTP=$(curl -s -o /tmp/meta_create.json -w "%{http_code}" -X POST https://api.github.com/user/repos \
  -H "Authorization: Bearer ${GH_TOKEN}" -H "Accept: application/vnd.github+json" \
  -d '{"name":"meta","description":"МЕТА-КАРТА вселенной из публичного API. Подделка = красный CI."}')
case "$HTTP" in
  201) echo "✓ репо meta создано";;
  422) echo "• репо meta уже существует — вселяю в него";;
  *)   echo "✗ API ответил ${HTTP}; детали не печатаю."; exit 1;;
esac

git remote add origin "https://github.com/${LOGIN}/meta.git"
# ключ идёт в git только через одноразовый credential helper — нигде не хранится
GIT_TERMINAL_PROMPT=0 git \
  -c credential.helper='!f(){ printf "username=x-access-token\npassword=%s\n" "$GH_TOKEN"; };f' \
  push -qu origin main
echo "✓ Вселено: https://github.com/${LOGIN}/meta"
echo "  Дальше само: meta-map обновит карту, meta-drift встанет на стражу."
