"""Зонд демо-орбиты: минимальные функции под счётчик тестов."""


def add(a, b):
    return a + b


def orbit_radius(mass, speed):
    """Фиктивная формула для демо-счётчиков."""
    return round(mass / speed, 3) if speed else 0
