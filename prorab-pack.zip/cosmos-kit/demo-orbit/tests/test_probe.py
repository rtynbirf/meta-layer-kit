import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "probe"))

from probe import add, orbit_radius  # noqa: E402


class TestProbe(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(2, 3), 5)

    def test_add_negative(self):
        self.assertEqual(add(-2, 3), 1)

    def test_orbit_radius(self):
        self.assertEqual(orbit_radius(6, 3), 2.0)
        self.assertEqual(orbit_radius(6, 0), 0)


if __name__ == "__main__":
    unittest.main()
