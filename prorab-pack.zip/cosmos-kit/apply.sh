#!/usr/bin/env bash
# apply.sh — дверь владельца: создаёт репо на СВОЁМ аккаунте и вселяет cosmos-kit.
# Ключ — только GH_TOKEN из окружения: не в argv, не в URL, не в .git/config, не в логах.
set -euo pipefail
cd "$(dirname "$0")"

: "${GH_TOKEN:?Дверь заперта: на своей машине export GH_TOKEN=... (fine-grained: Contents RW + Administration RW) и запускай снова}"

REPO="${1:-cosmos}"
API="https://api.github.com"
AUTH=(-H "Authorization: Bearer ${GH_TOKEN}" -H "Accept: application/vnd.github+json")

LOGIN=$(curl -sf "${AUTH[@]}" "$API/user" | python3 -c "import sys,json;print(json.load(sys.stdin)['login'])")
echo "Ключ открывает дом: ${LOGIN}. Создаю репо ${REPO}..."

HTTP=$(curl -s -o /tmp/gh_create.json -w "%{http_code}" -X POST "${AUTH[@]}" \
  "$API/user/repos" \
  -d "{\"name\":\"${REPO}\",\"description\":\"COSMOS: карта из источников истины, дрейф невозможен\"}")
case "$HTTP" in
  201) echo "репо создано";;
  422) echo "репо уже существует — вселяю в него";;
  *)   echo "API ответил ${HTTP}:"; cat /tmp/gh_create.json; exit 1;;
esac

git init -q -b main
git add -A
git -c user.name="${LOGIN}" -c user.email="${LOGIN}@users.noreply.github.com" \
  commit -qm "cosmos-kit: карта из источников истины, дрейф невозможен"
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/${LOGIN}/${REPO}.git"
# ключ идёт в git только через одноразовый credential helper — нигде не хранится
GIT_TERMINAL_PROMPT=0 git \
  -c credential.helper='!f(){ printf "username=x-access-token\npassword=%s\n" "$GH_TOKEN"; };f' \
  push -qu origin main
echo "✓ Вселено: https://github.com/${LOGIN}/${REPO}"
echo "  CI cosmos-map пересоберёт карту, cosmos-drift встанет на стражу."
