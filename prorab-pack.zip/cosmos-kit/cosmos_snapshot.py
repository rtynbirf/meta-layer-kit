#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cosmos_snapshot.py — карта космоса из источников истины: диск + git + тесты.
Без ключей, без сети, только stdlib (Python 3.8+).

Команды:
  snapshot [--root DIR]  собрать карту орбит → cosmos/map.json + cosmos/COSMOS.md
  drift    [--root DIR]  пересчитать факты и сверить с картой на диске; exit 1 = враньё/устарело
  status   [--root DIR]  напечатать карту офлайн из map.json

Правило №1: руками счётчик — ЗАПРЕЩЁН. Число в COSMOS.md живёт только как маркер:
  <!--c:имя-->123<!--/c-->
Его заполняет snapshot и проверяет drift. Подменишь рукой — drift краснеет.

Орбиты: корень (--root) как орбита «root» (только файлы верхнего уровня) и каждый
подкаталог как отдельная орбита. Скрытые каталоги (.git, .github, …), __pycache__
и сам каталог карты cosmos не считаются.

Источники счётчиков:
  файлы/байты — диск;
  коммиты/последний пуш — git rev-list/log по пути орбиты; только когда
    --root — КОРЕНЬ git-репозитория (без хождения вверх по дереву, иначе
    счётчик зависел бы от того, какие репозитории лежат вокруг);
  тесты — функции def test_* в файлах test_*.py / *_test.py;
  отпечаток — sha256 по отсортированному списку (путь, размер).
"""
import argparse
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

TOTAL_KEYS = ("orbits", "files", "bytes", "commits", "tests")
TEST_FILE = re.compile(r"(^test_.*\.py$|.*_test\.py$)")
TEST_DEF = re.compile(r"(?m)^\s*def\s+(test_[A-Za-z0-9_]*)\s*\(")


def git(*args, cwd):
    try:
        r = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True,
                           text=True, timeout=30)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def orbit_entries(root: Path, name: str):
    """(относительный путь, размер) для файлов орбиты; служебные каталоги мимо."""
    if name == "(root)":
        candidates = [p for p in root.iterdir() if p.is_file()]
    else:
        candidates = [p for p in (root / name).rglob("*") if p.is_file()]
    out = []
    for p in candidates:
        parts = set(p.parts)
        if ".git" in parts or "__pycache__" in parts:
            continue
        out.append((p.relative_to(root).as_posix(), p.stat().st_size))
    return out


def fingerprint(entries):
    h = hashlib.sha256()
    for rel, size in sorted(entries):
        h.update(rel.encode("utf-8"))
        h.update(b"\x00")
        h.update(str(size).encode("ascii"))
        h.update(b"\x00")
    return h.hexdigest()[:12]


def scan_orbit(root: Path, name: str, in_repo: bool) -> dict:
    entries = orbit_entries(root, name)
    tests = 0
    for rel, _ in entries:
        if TEST_FILE.match(Path(rel).name):
            try:
                tests += len(TEST_DEF.findall((root / rel).read_text(
                    encoding="utf-8", errors="ignore")))
            except Exception:
                pass
    rel = "." if name == "(root)" else name
    if in_repo:
        commits = git("rev-list", "--count", "HEAD", "--", rel, cwd=root)
        last = git("log", "-1", "--format=%cs", "--", rel, cwd=root)
        commits = int(commits) if commits.isdigit() else 0
        last = last or None
    else:
        commits, last = 0, None
    return {
        "orbit": name,
        "files": len(entries),
        "bytes": sum(s for _, s in entries),
        "commits": commits,
        "last_commit": last,
        "tests": tests,
        "state": fingerprint(entries),
    }


def scan(root: Path):
    names = ["(root)"] + sorted(
        d.name for d in root.iterdir()
        if d.is_dir() and d.name != "cosmos" and not d.name.startswith("."))
    top = git("rev-parse", "--show-toplevel", cwd=root)
    in_repo = bool(top) and Path(top).resolve() == root
    orbits = [scan_orbit(root, n, in_repo) for n in names]
    if in_repo:
        head = git("rev-list", "--count", "HEAD", cwd=root)
        commits = int(head) if head.isdigit() else 0
    else:
        commits = 0
    total = {
        "orbits": len(orbits),
        "files": sum(o["files"] for o in orbits),
        "bytes": sum(o["bytes"] for o in orbits),
        "commits": commits,
        "tests": sum(o["tests"] for o in orbits),
    }
    return orbits, total, in_repo


def mangle(name: str) -> str:
    return re.sub(r"[^a-z0-9_.-]+", "_", name.lower())


def write_map(root: Path, orbits, total, in_repo):
    """COSMOS.md с числами, вписанными ТОЛЬКО маркерами, + map.json."""
    out = root / "cosmos"
    out.mkdir(exist_ok=True)
    generated = datetime.now(timezone.utc).isoformat(timespec="seconds")
    (out / "map.json").write_text(
        json.dumps({"generated_at": generated, "in_git_repo": in_repo,
                    "orbits": orbits, "total": total},
                   ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    L = []
    ap = L.append
    ap("# COSMOS: карта «%s»" % root.name)
    ap("")
    ap("Собрана `cosmos_snapshot.py` из источников истины: диск + git + тесты.")
    ap("Сборка: `%s`. Без ключей, без сети. Числа — только маркеры; руками счётчик запрещён." % generated)
    ap("Git-источник: %s." % ("да — --root корень репозитория" if in_repo
                              else "нет — --root не корень репозитория, коммиты 0"))
    ap("")
    ap("## Итог")
    ap("")
    ap("| Показатель | Значение |")
    ap("|---|---|")
    for key in TOTAL_KEYS:
        ap("| %s | <!--c:%s-->%d<!--/c--> |" % (key, key, total[key]))
    ap("")
    ap("## Орбиты")
    ap("")
    ap("| Орбита | Файлы | Байт | Коммиты | Тесты | Последний коммит | Отпечаток |")
    ap("|---|---|---|---|---|---|---|")
    for o in orbits:
        n = mangle(o["orbit"])
        ap("| %s | <!--c:files_%s-->%d<!--/c--> | <!--c:bytes_%s-->%d<!--/c--> | "
           "<!--c:commits_%s-->%d<!--/c--> | <!--c:tests_%s-->%d<!--/c--> | %s | `%s` |" % (
               o["orbit"], n, o["files"], n, o["bytes"], n, o["commits"],
               n, o["tests"], o["last_commit"] or "—", o["state"]))
    ap("")
    ap("---")
    ap("*Карту вписал генератор; подделку ловит `drift` и красный CI.*")
    (out / "COSMOS.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return generated


def read_markers(md: Path) -> dict:
    text = md.read_text(encoding="utf-8")
    return {m.group(1): int(m.group(2))
            for m in re.finditer(r"<!--c:([a-z0-9_.-]+)-->([0-9]+)<!--/c-->", text)}


def expected_markers(orbits, total) -> dict:
    exp = {k: total[k] for k in TOTAL_KEYS}
    for o in orbits:
        n = mangle(o["orbit"])
        for k in ("files", "bytes", "commits", "tests"):
            exp["%s_%s" % (k, n)] = o[k]
    return exp


def cmd_snapshot(root: Path) -> int:
    orbits, total, in_repo = scan(root)
    generated = write_map(root, orbits, total, in_repo)
    print("Карта собрана: %s (cosmos/COSMOS.md + cosmos/map.json)" % root)
    print("Сборка %s | орбит %d | файлов %d | байт %d | коммитов %d | тестов %d"
          % (generated, total["orbits"], total["files"], total["bytes"],
             total["commits"], total["tests"]))
    return 0


def cmd_drift(root: Path) -> int:
    md = root / "cosmos" / "COSMOS.md"
    mj = root / "cosmos" / "map.json"
    if not md.exists() or not mj.exists():
        print("Дрейф: карты нет — сначала snapshot.")
        return 1
    orbits, total, in_repo = scan(root)
    problems = []
    got = read_markers(md)
    exp = expected_markers(orbits, total)
    for k in sorted(exp):
        if k not in got:
            problems.append("маркер %s исчез из COSMOS.md (по фактам: %d)" % (k, exp[k]))
        elif got[k] != exp[k]:
            problems.append("маркер %s: в карте %d, по фактам %d" % (k, got[k], exp[k]))
    for k in sorted(set(got) - set(exp)):
        problems.append("маркер %s в карте лишний (значение %d)" % (k, got[k]))
    snap = json.loads(mj.read_text(encoding="utf-8"))
    if snap.get("in_git_repo") != in_repo:
        problems.append("map.json[in_git_repo] не совпадает с фактами (%s)" % in_repo)
    if snap.get("orbits") != orbits:
        problems.append("map.json[orbits] не совпадает с фактами (диск/git менялись после сборки)")
    if snap.get("total") != total:
        problems.append("map.json[total] не совпадает с фактами")
    if problems:
        print("ДРЕЙФ ПОЙМАН — карта врёт фактам:")
        for p in problems:
            print("  ✗ " + p)
        print("Лечение: python3 cosmos_snapshot.py snapshot --root %s" % root)
        return 1
    print("Дрейф: 0. Карта = фактам: орбит %d | файлов %d | байт %d | коммитов %d | тестов %d"
          % (total["orbits"], total["files"], total["bytes"], total["commits"], total["tests"]))
    return 0


def cmd_status(root: Path) -> int:
    mj = root / "cosmos" / "map.json"
    if not mj.exists():
        print("Карты нет: python3 cosmos_snapshot.py snapshot --root %s" % root)
        return 1
    snap = json.loads(mj.read_text(encoding="utf-8"))
    t = snap["total"]
    print("Карта «%s», собрана %s" % (root.name, snap["generated_at"]))
    print("Git-источник: %s" % ("да" if snap.get("in_git_repo") else "нет"))
    print("Орбит: %d | Файлов: %d | Байт: %d | Коммитов: %d | Тестов: %d"
          % (t["orbits"], t["files"], t["bytes"], t["commits"], t["tests"]))
    for o in snap["orbits"]:
        print("  %-10s файлы %3d | байт %7d | коммиты %2d | тесты %d | пуш %s | отпечаток %s"
              % (o["orbit"], o["files"], o["bytes"], o["commits"], o["tests"],
                 o["last_commit"] or "—", o["state"]))
    return 0


def main():
    ap = argparse.ArgumentParser(description="карта космоса из источников истины")
    ap.add_argument("command", choices=["snapshot", "drift", "status"])
    ap.add_argument("--root", default=".", help="корень космоса (по умолчанию текущий каталог)")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir():
        print("Корень не найден: %s" % root)
        return 1
    if args.command == "snapshot":
        return cmd_snapshot(root)
    if args.command == "drift":
        return cmd_drift(root)
    return cmd_status(root)


if __name__ == "__main__":
    sys.exit(main())
