#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selftest.py — фикстурный полигон для universe.py.

Строит мини-вселенную (git-репо, песни, паспорта, ledger, тесты, доки),
прогоняет все команды и проверяет: счётчики точны, render честен,
drift ловит враньё, неизвестные счётчики и протухший снапшот.

Запуск:  python selftest.py [--keep] [--tmp-dir PATH]
По умолчанию полигон живёт во временном каталоге и удаляется после успеха
(при провале остаётся для разбора).
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

TOOL = Path(__file__).resolve().parent / "universe.py"
GITENV = {"GIT_AUTHOR_NAME": "f", "GIT_AUTHOR_EMAIL": "f@e.co",
          "GIT_COMMITTER_NAME": "f", "GIT_COMMITTER_EMAIL": "f@e.co"}


def sh(cmd, cwd):
    subprocess.run(cmd, cwd=str(cwd), check=True, env={**os.environ, **GITENV},
                   capture_output=True, text=True)


def git_repo(path, commits):
    path.mkdir(parents=True)
    sh(["git", "init", "-q"], path)
    f = path / "f.txt"
    for i in range(commits):
        f.write_text("v%d\n" % i, encoding="utf-8")
        sh(["git", "add", "."], path)
        sh(["git", "commit", "-q", "-m", "c%d" % i], path)


def build(root):
    (root / "singulyar" / "песни").mkdir(parents=True)
    for s in ("a", "b", "c"):
        (root / "singulyar" / "песни" / (s + ".md")).write_text("# песня %s\n" % s, encoding="utf-8")
    (root / "atlas" / "паспорта").mkdir(parents=True)
    for i in range(5):
        (root / "atlas" / "паспорта" / ("p%d.json" % i)).write_text("{}", encoding="utf-8")
    po = root / "polymath-os"
    po.mkdir()
    (po / ".test_count").write_text("12\n", encoding="utf-8")  # для сред без pytest
    (po / "INV_LEDGER.jsonl").write_text(
        "\n".join('{"n":%d}' % i for i in range(6)) + "\n", encoding="utf-8")
    t = po / "tests"
    t.mkdir()
    (t / "test_ok.py").write_text("def test_a(): pass\ndef test_b(): pass\n", encoding="utf-8")
    git_repo(root / "karta", 7)
    git_repo(root / "SWARM-SYNC", 4)

    (root / "README.md").write_text(
        "# Вселенная (фикстура)\n\n"
        "Песен: {{c:songs_singulyar}}\n"
        "Коммитов в карте: {{c:commits_karta}}\n"
        "В SWARM-SYNC: {{c:commits_swarm_sync}}\n", encoding="utf-8")
    (root / "витрина.md").write_text(
        "# Витрина\n\nРепо на карте: <!--c:repos_mapped-->99<!--/c--> (устарело намеренно)\n",
        encoding="utf-8")

    snap = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "owner": "fixture", "mode": "public-only",
        "repos": [
            {"name": "alpha", "private": False, "decoded": True},
            {"name": "beta", "private": False, "decoded": None},
            {"name": "gamma", "private": False, "decoded": True},
            {"name": "delta", "private": True, "decoded": False},
            {"name": "eps", "private": True, "decoded": None},
        ],
    }
    (root / "snapshot.json").write_text(
        json.dumps(snap, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    cfg = {
        "owner": "fixture",
        "repos": {"karta": {"path": "karta"}, "SWARM-SYNC": {"path": "SWARM-SYNC"}},
        "counters": {
            "songs_singulyar": {"type": "files", "path": "singulyar/песни", "glob": "**/*.md"},
            "tests_polymath_os": {"type": "pytest", "path": "polymath-os",
                                  "fallback_file": "polymath-os/.test_count"},
            "commits_karta": {"type": "git", "path": "karta"},
            "commits_swarm_sync": {"type": "git", "path": "SWARM-SYNC"},
            "passports_atlas": {"type": "files", "path": "atlas/паспорта", "glob": "**/*.json"},
            "ledger_records": {"type": "jsonl", "path": "polymath-os/INV_LEDGER.jsonl"},
            "repos_mapped": {"type": "snapshot", "key": "mapped"},
            "repos_published": {"type": "snapshot", "key": "published"},
            "repos_undecoded": {"type": "snapshot", "key": "undecoded"},
        },
        "docs": ["*.md"],
        "max_age_days": 14,
        "plans": ["voice-atlas-llm"],
    }
    (root / "universe.json").write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run(root, *args):
    return subprocess.run([sys.executable, str(TOOL), "--root", str(root)] + list(args),
                          capture_output=True, text=True)


def check(label, cond, extra=""):
    print("[%s] %s%s" % ("PASS" if cond else "FAIL", label,
                         ("  (" + extra + ")") if (extra and not cond) else ""))
    return bool(cond)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true", help="не удалять полигон")
    ap.add_argument("--tmp-dir", default="", help="где строить полигон")
    args = ap.parse_args()

    if args.tmp_dir:
        root = Path(args.tmp_dir).resolve()
        if root.exists():
            shutil.rmtree(root)
        root.mkdir(parents=True)
    else:
        root = Path(tempfile.mkdtemp(prefix="universe_fixture_"))
    build(root)

    pytest_on = subprocess.run([sys.executable, "-m", "pytest", "--version"],
                               capture_output=True).returncode == 0
    expected_tests = 2 if pytest_on else 12

    results = []

    # --- счётчики ---
    p = run(root, "counters")
    results.append(check("counters: exit 0", p.returncode == 0, p.stderr.strip()))
    vals = {k: v["value"] for k, v in json.loads(
        (root / "counters.json").read_text(encoding="utf-8"))["counters"].items()}
    for name, want in [("songs_singulyar", 3),
                       ("tests_polymath_os", expected_tests),
                       ("commits_karta", 7),
                       ("commits_swarm_sync", 4),
                       ("passports_atlas", 5),
                       ("ledger_records", 6),
                       ("repos_mapped", 5),
                       ("repos_published", 3),
                       ("repos_undecoded", 2)]:
        results.append(check("counters: %s == %d" % (name, want),
                             vals.get(name) == want, "получено %r" % vals.get(name)))

    # --- рендер ---
    p = run(root, "render")
    results.append(check("render: exit 0", p.returncode == 0, p.stderr.strip()))
    rd = (root / "README.md").read_text(encoding="utf-8")
    results.append(check("render: маркер songs заполнен",
                         "<!--c:songs_singulyar-->3<!--/c-->" in rd))
    results.append(check("render: маркер karta заполнен",
                         "<!--c:commits_karta-->7<!--/c-->" in rd))

    p = run(root, "render", "--check")
    results.append(check("render --check: exit 0 после рендера", p.returncode == 0, p.stderr.strip()))

    # --- дрейф на честной вселенной ---
    p = run(root, "drift")
    results.append(check("drift: exit 0 на честной вселенной", p.returncode == 0, p.stderr.strip()))

    # --- враньё ловится ---
    (root / "витрина.md").write_text(
        "# Витрина\n\nРепо на карте: <!--c:repos_mapped-->999<!--/c-->\n", encoding="utf-8")
    p = run(root, "drift")
    results.append(check("drift: ловит враньё в маркере (exit 1)", p.returncode == 1,
                         (p.stdout + p.stderr).strip()))
    results.append(check("drift: называет виновника", "repos_mapped" in p.stderr))

    # --- render лечит враньё ---
    p = run(root, "render")
    results.append(check("render: исправляет враньё", p.returncode == 0, p.stderr.strip()))
    p = run(root, "drift")
    results.append(check("drift: снова exit 0", p.returncode == 0, p.stderr.strip()))

    # --- счётчик без источника ловится ---
    (root / "план.md").write_text("Планы: {{c:nope}}\n", encoding="utf-8")
    p = run(root, "drift")
    results.append(check("drift: ловит неизвестный счётчик",
                         p.returncode == 1 and "nope" in p.stderr, p.stderr.strip()))
    (root / "план.md").unlink()

    # --- протухший снапшот ловится ---
    snap = json.loads((root / "snapshot.json").read_text(encoding="utf-8"))
    snap["generated_at"] = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat(timespec="seconds")
    (root / "snapshot.json").write_text(json.dumps(snap, ensure_ascii=False), encoding="utf-8")
    p = run(root, "drift")
    results.append(check("drift: ловит протухший снапшот",
                         p.returncode == 1 and "протух" in p.stderr, p.stderr.strip()))
    snap["generated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    (root / "snapshot.json").write_text(json.dumps(snap, ensure_ascii=False), encoding="utf-8")

    # --- снапшот офлайн ---
    p = run(root, "snapshot")
    results.append(check("snapshot офлайн: exit 0", p.returncode == 0, p.stderr.strip()))
    results.append(check("snapshot офлайн: показывает 5/3", "5" in p.stdout and "3" in p.stdout))

    # --- статус из фактов ---
    p = run(root, "status")
    results.append(check("status: exit 0", p.returncode == 0, p.stderr.strip()))
    results.append(check("status: видит недекодированные", "не декодировано" in p.stdout))
    results.append(check("status: видит план вне карты", "вне карты" in p.stdout))

    ok = all(results)
    print("\n%s: %d/%d" % ("✓ ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ" if ok else "✗ ЕСТЬ ПРОВАЛЫ",
                           sum(results), len(results)))
    if ok and not args.keep:
        shutil.rmtree(root, ignore_errors=True)
    else:
        print("полигон: %s" % root)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
