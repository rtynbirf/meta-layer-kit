#!/usr/bin/env bash
# zapusk.sh — единственная дверь в ПОЛНУЮ вселенную (публичный + приватный слой).
# Открывается ТОЛЬКО рукой владельца на ЕГО машине: токен живёт в переменной
# окружения — не в argv, не в URL, не в логах.
set -euo pipefail
cd "$(dirname "$0")"

if [ -z "${GH_TOKEN:-}" ] && [ -z "${GITHUB_TOKEN:-}" ]; then
  cat <<'EOF'
Дверь заперта: в окружении нет GH_TOKEN.
Владелец открывает так (на своей машине):
  export GH_TOKEN=...   # fine-grained: Contents Read+Write, Actions Read
  ./zapusk.sh
EOF
  exit 1
fi

echo "== 1/5 Снапшот вселенной (публичный + приватный слой, CI-вердикты) =="
python3 universe.py snapshot --refresh --with-ci
echo
echo "== 2/5 Счётчики из источников истины =="
python3 universe.py counters
echo
echo "== 3/5 Рендер документов =="
python3 universe.py render
echo
echo "== 4/5 Дрейф (exit 1 = враньё или протухло) =="
python3 universe.py drift
echo
echo "== 5/5 Статус из фактов =="
python3 universe.py status
echo
echo "✓ Вселенная вскрыта и честна. Карта: snapshot.json, счётчики: counters.json."
