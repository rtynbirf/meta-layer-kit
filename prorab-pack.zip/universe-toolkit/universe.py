#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
universe.py — метаслой вселенной: снапшот, счётчики, рендер, дрейф, статус.

ПРАВИЛО ВСЕЛЕННОЙ №1: руками счётчик — ЗАПРЕЩЁН.
Число в документе живёт только как маркер:
    {{c:имя}}                 — пустое место (заполняет команда render)
    <!--c:имя-->123<!--/c-->  — заполненный маркер (проверяет команда drift)

Токен: только через переменную окружения GH_TOKEN (или GITHUB_TOKEN).
Никогда не в argv, никогда в URL, никогда в логах.
Зависимости: только стандартная библиотека Python 3.7+.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

API = os.environ.get("UNIVERSE_API", "https://api.github.com").rstrip("/")
# UNIVERSE_API — для GitHub Enterprise и тестов с мок-сервером (selftest/mock).
PLACEHOLDER = re.compile(r"\{\{c:([A-Za-z0-9_]+)\}\}")
MARKER = re.compile(r"<!--\s*c:([A-Za-z0-9_]+)\s*-->\s*(\d+)\s*<!--\s*/c\s*-->")
SKIP_DIRS = {".git", "node_modules", "__pycache__"}
SKIP_FILES = {"counters.json", "snapshot.json"}


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def fail(msg, code=1):
    print("✗ " + msg, file=sys.stderr)
    sys.exit(code)


def load_config(root):
    p = root / "universe.json"
    if not p.exists():
        return None
    with p.open(encoding="utf-8") as f:
        return json.load(f)


def get_token():
    return os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN") or ""


def api_get(url, token=""):
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "universe-meta/1.0")
    req.add_header("Accept", "application/vnd.github+json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.load(resp)


def resolve(base, p):
    q = Path(p)
    return q if q.is_absolute() else base / q


# ---------------------------------------------------------------- снапшот ---

def snapshot_stats(snap):
    repos = snap.get("repos", [])
    return {
        "mapped": len(repos),
        "published": sum(1 for r in repos if not r.get("private")),
        "undecoded": sum(1 for r in repos if r.get("decoded") is None),
    }


def print_summary(snap, path):
    repos = snap.get("repos", [])
    st = snapshot_stats(snap)
    out = print
    out("Снапшот: " + str(path))
    out("Владелец: %s   режим: %s   собран: %s"
        % (snap.get("owner"), snap.get("mode"), snap.get("generated_at")))
    out("На карте: %d   опубликовано: %d   приватных: %d   не декодировано: %d"
        % (st["mapped"], st["published"], st["mapped"] - st["published"], st["undecoded"]))
    fresh = sorted([r for r in repos if r.get("pushed_at")],
                   key=lambda r: r["pushed_at"], reverse=True)[:5]
    if fresh:
        out("")
        out("Свежие пушы:")
        for r in fresh:
            mark = "" if not r.get("private") else " (приват)"
            out("  %s  %s%s" % (str(r.get("pushed_at"))[:10], r.get("name"), mark))
    return 0


def cmd_snapshot(args):
    root = Path(args.root).resolve()
    token = get_token()
    out_path = Path(args.out) if args.out else root / "snapshot.json"

    if not args.refresh:
        if not out_path.exists():
            fail("нет %s — запусти snapshot --refresh (или укажи --owner НИК)" % out_path, 2)
        snap = json.loads(out_path.read_text(encoding="utf-8"))
        rc = print_summary(snap, out_path)
        try:
            dt = datetime.fromisoformat(str(snap.get("generated_at")).replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - dt).days
            cfg = load_config(root) or {}
            max_age = int(cfg.get("max_age_days", 14))
            if age > max_age:
                print("⚠ Снапшоту %d дн (лимит %d) — витрина может врать молча; запусти --refresh"
                      % (age, max_age), file=sys.stderr)
        except Exception:
            pass
        return rc

    owner = args.owner or ""
    mode = "public-only"
    if not owner:
        if not token:
            fail("не задан --owner и нет GH_TOKEN: либо --owner НИК, либо экспортируй GH_TOKEN")
        owner = api_get(API + "/user", token)["login"]
        mode = "auth-all"

    repos, page = [], 1
    while True:
        if mode == "auth-all":
            url = "%s/user/repos?per_page=100&page=%d&visibility=all&affiliation=owner&sort=pushed" % (API, page)
        else:
            url = "%s/users/%s/repos?per_page=100&page=%d&sort=pushed" % (API, owner, page)
        try:
            batch = api_get(url, token)
        except urllib.error.HTTPError as e:
            fail("GitHub API вернул %d (без токена лимит 60 запросов/час; приватные репо видны только с токеном)" % e.code)
        repos.extend(batch)
        if len(batch) < 100 or page >= 40:
            break
        page += 1

    if args.with_ci:
        if not token:
            print("⚠ --with-ci без токена пропущен: лимит без токена слишком мал", file=sys.stderr)
        else:
            for r in repos:
                try:
                    runs = api_get("%s/repos/%s/actions/runs?per_page=1" % (API, r["full_name"]), token)
                    wr = runs.get("workflow_runs") or []
                    r["last_ci"] = wr[0].get("conclusion") if wr else None
                except Exception:
                    r["last_ci"] = None

    # слияние: decoded / note / прошлый last_ci переживают обновление
    old = {}
    if out_path.exists():
        try:
            old = {r["name"]: r for r in json.loads(out_path.read_text(encoding="utf-8")).get("repos", [])}
        except Exception:
            old = {}
    merged = []
    for r in repos:
        prev = old.get(r.get("name"), {})
        merged.append({
            "name": r.get("name"),
            "full_name": r.get("full_name"),
            "private": bool(r.get("private")),
            "fork": bool(r.get("fork")),
            "archived": bool(r.get("archived")),
            "pushed_at": r.get("pushed_at"),
            "description": r.get("description") or "",
            "default_branch": r.get("default_branch"),
            "url": r.get("html_url"),
            "last_ci": r.get("last_ci", prev.get("last_ci")),
            "decoded": prev.get("decoded"),
            "note": prev.get("note", ""),
        })
    snap = {"generated_at": now_iso(), "owner": owner, "mode": mode, "repos": merged}
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(snap, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return print_summary(snap, out_path)


# --------------------------------------------------------------- счётчики ---

def compute_counter(root, name, spec, cache, errors):
    """Считает ОДИН счётчик из источника истины. None + запись в errors при неудаче."""
    ctype = spec.get("type", "")
    try:
        if ctype == "git":
            path = resolve(root, spec["path"])
            if not (path / ".git").exists():
                raise FileNotFoundError("нет git-репо: %s" % path)
            res = subprocess.run(["git", "-C", str(path), "rev-list", "--count", "HEAD"],
                                 capture_output=True, text=True, timeout=60)
            if res.returncode != 0:
                raise RuntimeError("git rev-list: %s" % res.stderr.strip())
            return int(res.stdout.strip())

        if ctype == "files":
            path = resolve(root, spec["path"])
            if not path.exists():
                raise FileNotFoundError("нет пути: %s" % path)
            return sum(1 for f in path.glob(spec.get("glob", "**/*")) if f.is_file())

        if ctype == "jsonl":
            path = resolve(root, spec["path"])
            if not path.exists():
                raise FileNotFoundError("нет файла: %s" % path)
            return sum(1 for line in path.read_text(encoding="utf-8", errors="replace").splitlines()
                       if line.strip())

        if ctype == "pytest":
            path = resolve(root, spec["path"])
            if not path.exists():
                raise FileNotFoundError("нет пути: %s" % path)
            res = subprocess.run([sys.executable, "-m", "pytest", str(path), "--collect-only", "-q"],
                                 capture_output=True, text=True, timeout=180)
            m = re.search(r"(\d+) tests? collected", res.stdout)
            if m:
                return int(m.group(1))
            fb = spec.get("fallback_file")  # среда без pytest: читаем сохранённое число
            if fb:
                fbp = resolve(root, fb)
                if fbp.exists():
                    return int(fbp.read_text(encoding="utf-8").strip())
            raise RuntimeError("pytest не дал 'N tests collected': %s" % (res.stderr.strip()[-120:] or "нет pytest"))

        if ctype == "snapshot":
            key = spec.get("key", "mapped")
            if "stats" not in cache:
                sp = root / "snapshot.json"
                if not sp.exists():
                    raise FileNotFoundError("нет snapshot.json — запусти: python universe.py snapshot --refresh")
                cache["stats"] = snapshot_stats(json.loads(sp.read_text(encoding="utf-8")))
            if key not in cache["stats"]:
                raise KeyError("неизвестный ключ снапшота: %s (есть mapped/published/undecoded)" % key)
            return cache["stats"][key]

        raise ValueError("неизвестный тип счётчика: %r" % ctype)
    except Exception as e:
        errors.append("%s: %s" % (name, e))
        return None


def gather_values(root, cfg):
    cache, errors, values = {}, [], {}
    for name, spec in (cfg.get("counters") or {}).items():
        v = compute_counter(root, name, spec, cache, errors)
        if v is not None:
            values[name] = v
    return values, errors


def cmd_counters(args):
    root = Path(args.root).resolve()
    cfg = load_config(root)
    if not cfg:
        fail("нет %s — конфиг обязателен для счётчиков" % (root / "universe.json"), 2)
    if not cfg.get("counters"):
        fail("в universe.json нет секции counters", 2)
    values, errors = gather_values(root, cfg)
    for e in errors:
        print("✗ счётчик " + e, file=sys.stderr)
    (root / "counters.json").write_text(json.dumps(
        {"generated_at": now_iso(),
         "counters": {k: {"value": v, "type": cfg["counters"][k].get("type", "")}
                      for k, v in sorted(values.items())}},
        ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("Счётчики (из источников истины, не из головы):")
    w = max([len(k) for k in values] + [7])
    for k in sorted(values):
        print("  %-*s  %7d" % (w, k, values[k]))
    print("\nИтого: %d счётчиков → counters.json" % len(values))
    return 1 if errors else 0


# ------------------------------------------------------- документы/рендер ---

def doc_files(root, cfg):
    pats = cfg.get("docs") or ["**/*.md"]
    files = set()
    for pat in pats:
        for p in root.glob(pat):
            if p.is_file() and not (set(p.parts) & SKIP_DIRS) and p.name not in SKIP_FILES:
                files.add(p)
    return sorted(files)


def render_text(text, values, changed):
    def fix_marker(m):
        name = m.group(1)
        if name not in values:
            return m.group(0)
        new = "<!--c:%s-->%d<!--/c-->" % (name, values[name])
        if new != m.group(0):
            changed.add(name)
        return new

    def fix_ph(m):
        name = m.group(1)
        if name not in values:
            return m.group(0)
        changed.add(name)
        return "<!--c:%s-->%d<!--/c-->" % (name, values[name])

    text = MARKER.sub(fix_marker, text)
    text = PLACEHOLDER.sub(fix_ph, text)
    return text


def cmd_render(args):
    root = Path(args.root).resolve()
    cfg = load_config(root)
    if not cfg:
        fail("нет %s" % (root / "universe.json"), 2)
    values, errors = gather_values(root, cfg)
    if errors:
        for e in errors:
            print("✗ счётчик " + e, file=sys.stderr)
        return 1

    dirty, unknown = [], set()
    for p in doc_files(root, cfg):
        orig = p.read_text(encoding="utf-8", errors="replace")
        for m in PLACEHOLDER.finditer(orig):
            if m.group(1) not in values:
                unknown.add(m.group(1))
        for m in MARKER.finditer(orig):
            if m.group(1) not in values:
                unknown.add(m.group(1))
        changed = set()
        new = render_text(orig, values, changed)
        if new != orig:
            dirty.append((p, changed))
            if not args.check:
                p.write_text(new, encoding="utf-8")

    if unknown:
        print("⚠ В документах счётчики без источника: %s — добавь их в universe.json"
              % ", ".join(sorted(unknown)), file=sys.stderr)

    if args.check:
        if dirty:
            for p, ch in dirty:
                print("✗ %s: требует рендера (%s)" % (p.name, ", ".join(sorted(ch))), file=sys.stderr)
            return 1
        print("✓ render --check: все маркеры актуальны")
        return 0

    if dirty:
        for p, ch in dirty:
            print("✓ %s: записано (%s)" % (p.name, ", ".join(sorted(ch))))
        print("\nОтрендерено файлов: %d" % len(dirty))
    else:
        print("✓ Нечего рендерить: все маркеры уже истинны")
    return 0


# ----------------------------------------------------------------- дрейф ---

def cmd_drift(args):
    root = Path(args.root).resolve()
    cfg = load_config(root)
    if not cfg:
        fail("нет %s" % (root / "universe.json"), 2)
    values, errors = gather_values(root, cfg)
    if errors:
        for e in errors:
            print("✗ счётчик " + e, file=sys.stderr)
        return 1

    problems, checked = [], 0
    for p in doc_files(root, cfg):
        text = p.read_text(encoding="utf-8", errors="replace")
        for m in MARKER.finditer(text):
            name, val = m.group(1), int(m.group(2))
            checked += 1
            if name not in values:
                problems.append("%s: маркер <!--c:%s--> ссылается на несуществующий счётчик" % (p.name, name))
            elif values[name] != val:
                problems.append("%s: <!--c:%s--> = %d, а источник истины говорит %d"
                                % (p.name, name, val, values[name]))
        for m in PLACEHOLDER.finditer(text):
            name = m.group(1)
            if name not in values:
                problems.append("%s: {{c:%s}} — нет такого счётчика" % (p.name, name))
            else:
                problems.append("%s: незаполненный {{c:%s}} — запусти render" % (p.name, name))

    sp = root / "snapshot.json"
    max_age = int(cfg.get("max_age_days", 14))
    if sp.exists():
        try:
            gen = json.loads(sp.read_text(encoding="utf-8")).get("generated_at", "")
            dt = datetime.fromisoformat(str(gen).replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - dt).days
            if age > max_age:
                problems.append("snapshot.json протух: %d дн > %d дн — витрина врёт молча; запусти snapshot --refresh"
                                % (age, max_age))
        except Exception:
            problems.append("snapshot.json не читается как JSON с полем generated_at")

    if problems:
        for pr in problems:
            print("✗ " + pr, file=sys.stderr)
        print("Дрейф: %d проблем(ы), маркеров проверено: %d" % (len(problems), checked), file=sys.stderr)
        return 1
    print("✓ Дрейф не обнаружен. Маркеров проверено: %d, счётчиков: %d" % (checked, len(values)))
    return 0


# ---------------------------------------------------------------- статус ---

def status_label(decoded, last_ci, has_wf, has_tests, in_plans):
    if decoded is None:
        return "не декодировано"
    if in_plans:
        if last_ci == "success":
            return "план противоречит фактам (CI зелёный) — убери из планов"
        return "план"
    if last_ci == "success":
        return "работает"
    if last_ci:
        return "прототип (CI: %s)" % last_ci
    if has_wf and has_tests:
        return "претендент (CI+тесты на месте; вердикт после --refresh --with-ci)"
    if has_wf or has_tests:
        return "прототип"
    return "прототип (нет ни CI, ни тестов)"


def cmd_status(args):
    root = Path(args.root).resolve()
    cfg = load_config(root)
    if not cfg:
        fail("нет %s" % (root / "universe.json"), 2)
    sp = root / "snapshot.json"
    if not sp.exists():
        fail("нет snapshot.json — запусти snapshot --refresh", 2)
    snap = json.loads(sp.read_text(encoding="utf-8"))
    plans = set(cfg.get("plans") or [])
    repos_cfg = cfg.get("repos") or {}

    rows = []
    for r in snap.get("repos", []):
        name = r.get("name", "?")
        local = repos_cfg.get(name) or {}
        lpath = resolve(root, local["path"]) if local.get("path") else None
        has_wf = has_tests = False
        if lpath and Path(lpath).exists():
            lp = Path(lpath)
            wf = lp / ".github" / "workflows"
            has_wf = wf.exists() and (any(wf.glob("*.yml")) or any(wf.glob("*.yaml")))
            has_tests = (lp / "tests").exists() or (lp / "test").exists() or (lp / "conftest.py").exists()
        label = status_label(r.get("decoded"), r.get("last_ci"), has_wf, has_tests, name in plans)
        rows.append((name, label, str(r.get("pushed_at") or "")[:10], bool(r.get("private"))))

    print("Статус вселенной (из фактов, не из амбиций):")
    w = max([len(n) for n, _, _, _ in rows] + [7])
    for name, label, pushed, priv in rows:
        mark = "" if not priv else " (приват)"
        print("  %-*s  %s  %s%s" % (w, name, pushed or "—", label, mark))

    counts = {}
    for _, lab, _, _ in rows:
        counts[lab] = counts.get(lab, 0) + 1
    print("\nСводка:")
    for lab in sorted(counts):
        print("  %-4d %s" % (counts[lab], lab))

    in_map = {r.get("name") for r in snap.get("repos", [])}
    ghosts = [p for p in sorted(plans) if p not in in_map]
    if ghosts:
        print("\nПланы вне карты (обещано, но в снапшоте отсутствует):")
        for g in ghosts:
            print("  ⚠ " + g)
    return 0


# ------------------------------------------------------------------ main ---

def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="universe",
        description="метаслой вселенной: снапшот / счётчики / рендер / дрейф / статус")
    ap.add_argument("--root", default=".", help="каталог с universe.json (по умолчанию текущий)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("snapshot", help="карта вселенной: читать snapshot.json или собрать с API")
    p.add_argument("--refresh", action="store_true", help="собрать свежий снапшот с GitHub API")
    p.add_argument("--owner", default="", help="владелец (без --owner и с GH_TOKEN — свой аккаунт)")
    p.add_argument("--with-ci", action="store_true", help="добавить вердикт последнего CI-запуска (нужен токен)")
    p.add_argument("--out", default="", help="куда писать snapshot.json (по умолчанию <root>/snapshot.json)")

    sub.add_parser("counters", help="счётчики из источников истины → counters.json")

    p = sub.add_parser("render", help="заполнить {{c:...}} и поправить устаревшие маркеры в документах")
    p.add_argument("--check", action="store_true", help="ничего не писать; exit 1, если нужен рендер")

    sub.add_parser("drift", help="проверить документы и свежесть снапшота (exit 1 = дрейф)")
    sub.add_parser("status", help="статус репо из фактов: работает / прототип / план / не декодировано")

    args = ap.parse_args(argv)
    return {
        "snapshot": cmd_snapshot,
        "counters": cmd_counters,
        "render": cmd_render,
        "drift": cmd_drift,
        "status": cmd_status,
    }[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
